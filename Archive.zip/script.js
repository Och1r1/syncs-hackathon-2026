const q = sel => document.querySelector(sel);
const qa = sel => [...document.querySelectorAll(sel)];

/* =========================================================
   HOME ARCHIVE DATA (existing exhibit panel on the homepage)
   ========================================================= */
const countries = {
  vietnam: {
    number: '001 / 034', country: 'Vietnam', seal: '★', stamp: 'VN',
    game: 'Ô Ăn Quan', alias: 'Also known as Ô Quan · a traditional Vietnamese strategy game.',
    description: 'A counting and strategy game remembered across generations in Vietnam. Its simple board hides careful planning, mental arithmetic and a strong social tradition.',
    preview: 'assets/vn-preview.png', title: 'Ô Ăn Quan Board', type: 'Game board', markerColor: '#b84a2f',
    steps: [
      'Players distribute pieces through the board’s small fields.',
      'Pieces are collected and redistributed according to the next field.',
      'The aim is to capture more pieces through careful counting and timing.'
    ]
  },
  japan: {
    number: '002 / 034', country: 'Japan', seal: '日', stamp: 'JP',
    game: 'Kemari', alias: 'A ceremonial ball game associated with Japan’s imperial court.',
    description: 'Kemari is cooperative rather than competitive. Players keep a ball in the air together, turning graceful movement, clothing and ritual into part of the experience.',
    preview: 'assets/jp-card.png', title: 'Kemari Ball', type: 'Ceremonial ball', markerColor: '#c56f37', labelX: '-62px', labelY: '19px',
    steps: [
      'Players form a circle in a defined playing area.',
      'The ball is kept in the air using controlled kicks.',
      'The shared goal is rhythm, elegance and keeping the rally alive.'
    ]
  },
  ghana: {
    number: '003 / 034', country: 'Ghana', seal: '✦', stamp: 'GH',
    game: 'Oware', alias: 'A member of the mancala family of sowing and counting games.',
    description: 'Oware transforms a simple row of pits and seeds into a deep strategy game. It has long been played socially across West Africa and passed on through direct teaching.',
    preview: 'assets/gh-card.png', title: 'Oware Board', type: 'Sowing board', markerColor: '#7d6b2b',
    steps: [
      'Choose one of your pits and pick up all of its seeds.',
      'Sow the seeds one by one into the following pits.',
      'Capture according to the board state and finish with the larger store.'
    ]
  },
  mongolia: {
    number: '004 / 034', country: 'Mongolia', seal: 'ᠮ', stamp: 'MN',
    game: 'Shagai', alias: 'Sheep anklebones, thrown for games, chance and fortune-telling.',
    description: 'Shagai have been used across the Mongolian steppe for generations — for children’s games, for teaching counting, and for reading fortune in the four positions a bone can land on.',
    preview: 'assets/vn-preview.png', title: 'Shagai Anklebone', type: 'Bone piece', markerColor: '#9463a0',
    steps: [
      'Four anklebones are cast onto a flat surface or felt.',
      'Each bone settles into one of four positions: horse, camel, sheep or goat.',
      'The resulting combination is read as a fortune or used to score a game.'
    ]
  }
};

const atlasEntries = {
  southKorea: {
    number: '005 / 034', country: 'South Korea', seal: 'KR', stamp: 'KR',
    game: 'Yut Nori (윷놀이)', alias: 'A Korean board race game played by throwing four wooden sticks.',
    description: 'Players throw four wooden sticks and move pieces around a board according to how the sticks land.',
    preview: 'assets/vn-preview.png', title: 'Yut Nori Sticks', type: 'Board race game', markerColor: '#b84a2f', labelX: '-106px',
    steps: ['Throw four wooden sticks.', 'Read the landing pattern as a move value.', 'Move pieces around the board and try to bring them home first.']
  },
  china: {
    number: '006 / 034', country: 'China', seal: 'CN', stamp: 'CN',
    game: 'Jianzi (毽子)', alias: 'A shuttlecock kicking game played without using the hands.',
    description: 'Players keep a weighted shuttlecock in the air using their feet, knees and body without using their hands.',
    preview: 'assets/jp-card.png', title: 'Jianzi Shuttlecock', type: 'Shuttlecock game', markerColor: '#d86f38', labelY: '17px',
    steps: ['Serve the weighted shuttlecock into the air.', 'Keep it airborne using feet, knees and body control.', 'Continue the rally without using hands.']
  },
  india: {
    number: '007 / 034', country: 'India', seal: 'IN', stamp: 'IN',
    game: 'Pachisi', alias: 'An ancient cross-shaped race board game using shells or dice.',
    description: 'Ancient cross-shaped board game where players race pieces around the board using cowrie shells or dice.',
    preview: 'assets/vn-preview.png', title: 'Pachisi Board', type: 'Board race game', markerColor: '#d28a30',
    steps: ['Roll cowrie shells or dice.', 'Move pieces around the cross-shaped track.', 'Race all pieces safely to the centre.']
  },
  thailand: {
    number: '008 / 034', country: 'Thailand', seal: 'TH', stamp: 'TH',
    game: 'Makruk (หมากรุก)', alias: 'A traditional Thai strategy board game related to chess.',
    description: 'Traditional Thai strategy board game related to chess, with distinctive pieces and rules.',
    preview: 'assets/jp-card.png', title: 'Makruk Pieces', type: 'Strategy board game', markerColor: '#b84a2f', labelX: '-97px', labelY: '14px',
    steps: ['Set up the Thai chess pieces.', 'Move pieces according to Makruk rules.', 'Protect the king while forcing the opponent into defeat.']
  },
  philippines: {
    number: '009 / 034', country: 'Philippines', seal: 'PH', stamp: 'PH',
    game: 'Sungka', alias: 'A mancala-style board game using shells, stones or seeds.',
    description: 'Mancala-style game using a long wooden board with small shells or stones placed into pits.',
    preview: 'assets/gh-card.png', title: 'Sungka Board', type: 'Mancala board game', markerColor: '#3d8f82', labelX: '24px', labelY: '13px',
    steps: ['Choose a pit of shells or stones.', 'Distribute pieces one by one along the board.', 'Collect the most pieces in your store.']
  },
  indonesia: {
    number: '010 / 034', country: 'Indonesia', seal: 'ID', stamp: 'ID',
    game: 'Congklak', alias: 'An Indonesian mancala game played on a carved wooden board.',
    description: 'Traditional mancala game played with a carved wooden board and shells, seeds or stones.',
    preview: 'assets/gh-card.png', title: 'Congklak Board', type: 'Mancala board game', markerColor: '#3d8f82', labelX: '-104px',
    steps: ['Select shells, seeds or stones from a pit.', 'Sow them around the carved board.', 'Capture and store more pieces than the opponent.']
  },
  malaysia: {
    number: '011 / 034', country: 'Malaysia', seal: 'MY', stamp: 'MY',
    game: 'Congkak', alias: 'A Malaysian shell-and-seed board game from the mancala family.',
    description: 'Traditional board game where players distribute shells or seeds between holes to collect the most pieces.',
    preview: 'assets/gh-card.png', title: 'Congkak Board', type: 'Mancala board game', markerColor: '#3d8f82', labelY: '17px',
    steps: ['Pick up shells or seeds from one house.', 'Move around the board placing one piece in each hole.', 'Build the largest store.']
  },
  kazakhstan: {
    number: '012 / 034', country: 'Kazakhstan', seal: 'KZ', stamp: 'KZ',
    game: 'Asyk Atu', alias: 'A Central Asian target game played with sheep ankle bones.',
    description: 'Players use sheep ankle bones, called asyk, and attempt to knock other bones out of a target area.',
    preview: 'assets/vn-preview.png', title: 'Asyk Bones', type: 'Bone target game', markerColor: '#9463a0', labelX: '-108px',
    steps: ['Place ankle bones in a marked target area.', 'Throw or flick an asyk toward the target.', 'Score by knocking bones out of the area.']
  },
  turkiye: {
    number: '014 / 034', country: 'Türkiye', seal: 'TR', stamp: 'TR',
    game: 'Mangala', alias: 'A Turkish mancala game built around sowing and capturing stones.',
    description: "Turkish mancala game involving moving stones through pits and capturing an opponent's stones.",
    preview: 'assets/gh-card.png', title: 'Mangala Board', type: 'Mancala board game', markerColor: '#3d8f82',
    steps: ['Move stones through the row of pits.', 'Set up captures through careful counting.', "Collect more stones than the opponent."]
  },
  greece: {
    number: '015 / 034', country: 'Greece', seal: 'GR', stamp: 'GR',
    game: 'Tavli', alias: 'A family of backgammon-style games popular in Greece.',
    description: 'Extremely popular traditional family game consisting of several related backgammon-style games.',
    preview: 'assets/jp-card.png', title: 'Tavli Board', type: 'Backgammon-style game', markerColor: '#2d7a9f', labelX: '-82px',
    steps: ['Roll dice to move checkers.', 'Use blocks and captures to control the board.', 'Clear your pieces before the opponent.']
  },
  portugal: {
    number: '016 / 034', country: 'Portugal', seal: 'PT', stamp: 'PT',
    game: 'Jogo da Malha', alias: 'A Portuguese throwing game where metal discs are aimed at a pin.',
    description: 'Players throw metal discs, called malhas, toward a target pin and score by knocking it down or landing closest.',
    preview: 'assets/jp-card.png', title: 'Malha Discs', type: 'Throwing game', markerColor: '#2d7a9f', labelX: '-94px', labelY: '-20px',
    steps: ['Set the target pin at a distance.', 'Throw metal discs toward the pin.', 'Score by striking the pin or landing closest to it.']
  },
  italy: {
    number: '017 / 034', country: 'Italy', seal: 'IT', stamp: 'IT',
    game: 'Bocce', alias: 'An Italian target-ball game played toward a small pallino.',
    description: 'Players roll balls toward a smaller target ball called the pallino.',
    preview: 'assets/jp-card.png', title: 'Bocce Balls', type: 'Throwing game', markerColor: '#2d7a9f', labelY: '18px',
    steps: ['Set the pallino as the target.', 'Roll bocce balls toward it.', 'Score with the balls closest to the target.']
  },
  spain: {
    number: '018 / 034', country: 'Spain', seal: 'ES', stamp: 'ES',
    game: 'Calva', alias: 'A Spanish throwing game aimed at a wooden target.',
    description: 'Traditional throwing game where players throw a heavy object at a wooden target positioned some distance away.',
    preview: 'assets/jp-card.png', title: 'Calva Target', type: 'Throwing game', markerColor: '#2d7a9f', labelX: '-76px',
    steps: ['Set the wooden target at a distance.', 'Throw the heavy piece toward it.', 'Score when the target is struck cleanly.']
  },
  unitedKingdom: {
    number: '019 / 034', country: 'United Kingdom', seal: 'UK', stamp: 'UK',
    game: 'Skittles', alias: 'A traditional pub game where players knock down wooden pins.',
    description: 'Traditional pub game where players throw a ball or object to knock down wooden pins.',
    preview: 'assets/jp-card.png', title: 'Wooden Skittles', type: 'Pin game', markerColor: '#2d7a9f', labelX: '-138px',
    steps: ['Set up wooden pins.', 'Throw or roll the ball toward them.', 'Score by knocking down as many pins as possible.']
  },
  ireland: {
    number: '020 / 034', country: 'Ireland', seal: 'IE', stamp: 'IE',
    game: 'Road Bowling', alias: 'An Irish road game won by covering a route in the fewest throws.',
    description: 'Players throw a metal ball along a country road, trying to reach the finish using the fewest throws.',
    preview: 'assets/jp-card.png', title: 'Road Bowling Ball', type: 'Road throwing game', markerColor: '#2d7a9f', labelX: '-92px', labelY: '16px',
    steps: ['Start from a marked road point.', 'Throw the metal ball along the route.', 'Reach the finish in the fewest throws.']
  },
  netherlands: {
    number: '021 / 034', country: 'Netherlands', seal: 'NL', stamp: 'NL',
    game: 'Sjoelen', alias: 'A Dutch table game played by sliding wooden discs.',
    description: 'Players slide wooden discs down a long wooden board into numbered scoring compartments.',
    preview: 'assets/jp-card.png', title: 'Sjoelen Board', type: 'Table sliding game', markerColor: '#2d7a9f', labelY: '-26px',
    steps: ['Slide wooden discs down the board.', 'Aim for numbered scoring slots.', 'Use remaining turns to improve the score.']
  },
  finland: {
    number: '022 / 034', country: 'Finland', seal: 'FI', stamp: 'FI',
    game: 'Mölkky', alias: 'A Finnish skittle game where players aim for exactly 50 points.',
    description: 'Players throw a wooden pin at numbered wooden skittles and attempt to reach exactly 50 points.',
    preview: 'assets/jp-card.png', title: 'Mölkky Pins', type: 'Pin throwing game', markerColor: '#2d7a9f', labelX: '-82px',
    steps: ['Set up numbered wooden skittles.', 'Throw the mölkky pin.', 'Reach exactly 50 points without going over.']
  },
  sweden: {
    number: '023 / 034', country: 'Sweden', seal: 'SE', stamp: 'SE',
    game: 'Kubb', alias: 'A Swedish lawn game of batons, blocks and a central king.',
    description: 'Teams throw wooden batons to knock over wooden blocks before attacking the central King.',
    preview: 'assets/jp-card.png', title: 'Kubb Blocks', type: 'Lawn throwing game', markerColor: '#2d7a9f', labelY: '18px',
    steps: ['Set kubbs on each baseline and the king in the centre.', 'Throw batons to knock over opposing blocks.', 'Topple the king only after clearing the field.']
  },
  switzerland: {
    number: '024 / 034', country: 'Switzerland', seal: 'CH', stamp: 'CH',
    game: 'Hornussen', alias: 'A Swiss striking game involving a fast projectile and defensive paddles.',
    description: 'Players strike a small projectile called a Nouss while the opposing team tries to intercept it using large paddles.',
    preview: 'assets/jp-card.png', title: 'Hornussen Nouss', type: 'Striking field game', markerColor: '#2d7a9f', labelX: '24px', labelY: '-24px',
    steps: ['Strike the Nouss from the launch ramp.', 'Send it deep into the field.', 'Opponents try to intercept it with large paddles.']
  },
  mexico: {
    number: '025 / 034', country: 'Mexico', seal: 'MX', stamp: 'MX',
    game: 'Balero', alias: 'A cup-and-ball dexterity game played with a stringed wooden ball.',
    description: 'Traditional cup-and-ball game where a wooden ball attached by string must be caught on a stick or inside a cup.',
    preview: 'assets/vn-preview.png', title: 'Balero Toy', type: 'Dexterity toy game', markerColor: '#357a45',
    steps: ['Swing the attached wooden ball.', 'Control the string and timing.', 'Catch the ball on the stick or in the cup.']
  },
  unitedStates: {
    number: '026 / 034', country: 'United States', seal: 'US', stamp: 'US',
    game: 'Horseshoes', alias: 'A target throwing game played toward metal stakes.',
    description: 'Players throw horseshoes toward metal stakes to score points, especially by landing a ringer.',
    preview: 'assets/jp-card.png', title: 'Horseshoe Stakes', type: 'Throwing game', markerColor: '#357a45',
    steps: ['Stand at the pitching line.', 'Throw horseshoes toward the stake.', 'Score by landing close or making a ringer.']
  },
  canada: {
    number: '027 / 034', country: 'Canada', seal: 'CA', stamp: 'CA',
    game: 'Crokinole', alias: 'A Canadian disc-flicking board game.',
    description: 'Players flick wooden discs across a circular wooden board, trying to land them in high-scoring areas.',
    preview: 'assets/gh-card.png', title: 'Crokinole Board', type: 'Disc board game', markerColor: '#357a45', labelX: '-88px',
    steps: ['Flick wooden discs from the outer ring.', 'Aim for high-scoring circles.', 'Knock opposing discs away while keeping your own in play.']
  },
  brazil: {
    number: '028 / 034', country: 'Brazil', seal: 'BR', stamp: 'BR',
    game: 'Peteca', alias: 'A Brazilian hand-shuttlecock game with Indigenous roots.',
    description: 'Players strike a hand shuttlecock over a net using their palms; derived from Indigenous Brazilian traditions.',
    preview: 'assets/jp-card.png', title: 'Peteca Shuttlecock', type: 'Shuttlecock game', markerColor: '#357a45',
    steps: ['Serve the peteca with the palm.', 'Strike it over the net.', 'Keep the rally going through timing and placement.']
  },
  argentina: {
    number: '029 / 034', country: 'Argentina', seal: 'AR', stamp: 'AR',
    game: 'Pato', alias: "Argentina's national horseback game.",
    description: "Traditional horseback game combining elements resembling polo and basketball; Argentina's national sport.",
    preview: 'assets/jp-card.png', title: 'Pato Horseback Game', type: 'Horseback field game', markerColor: '#357a45',
    steps: ['Ride with teammates across the field.', 'Carry or contest the handled ball.', 'Score by throwing it through the target ring.']
  },
  chile: {
    number: '030 / 034', country: 'Chile', seal: 'CL', stamp: 'CL',
    game: 'Rayuela Chilena', alias: 'A Chilean throwing game aimed at a line in a clay-filled box.',
    description: 'Players throw metal discs toward a line stretched across a clay-filled target box.',
    preview: 'assets/jp-card.png', title: 'Rayuela Target Box', type: 'Throwing game', markerColor: '#357a45', labelX: '-82px',
    steps: ['Stand back from the clay-filled target box.', 'Throw the metal disc toward the line.', 'Score by landing closest to or on the line.']
  },
  peru: {
    number: '031 / 034', country: 'Peru', seal: 'PE', stamp: 'PE',
    game: 'Sapo', alias: 'A target table game where throws aim for holes and a frog mouth.',
    description: "Players throw metal coins or discs toward a table containing scoring holes and a metal frog's open mouth.",
    preview: 'assets/jp-card.png', title: 'Sapo Table', type: 'Target table game', markerColor: '#357a45',
    steps: ['Stand at the throwing line.', 'Toss coins or discs toward the scoring table.', "Aim for holes and the frog's mouth for higher points."]
  },
  southAfrica: {
    number: '032 / 034', country: 'South Africa', seal: 'ZA', stamp: 'ZA',
    game: 'Morabaraba', alias: 'A strategy board game where mills allow captures.',
    description: "Traditional strategy board game where players form lines of three pieces to capture an opponent's pieces.",
    preview: 'assets/gh-card.png', title: 'Morabaraba Board', type: 'Strategy board game', markerColor: '#7d6b2b',
    steps: ['Place pieces on board intersections.', 'Form lines of three pieces.', "Capture an opponent's piece when a line is formed."]
  },
  kenya: {
    number: '033 / 034', country: 'Kenya', seal: 'KE', stamp: 'KE',
    game: 'Bao', alias: 'An East African mancala-family strategy game.',
    description: 'East African mancala-family strategy game played using rows of pits and seeds or stones.',
    preview: 'assets/gh-card.png', title: 'Bao Board', type: 'Mancala board game', markerColor: '#7d6b2b',
    steps: ['Choose a pit containing seeds or stones.', 'Sow pieces through the board rows.', 'Capture through counting and board position.']
  },
  egypt: {
    number: '034 / 034', country: 'Egypt', seal: 'EG', stamp: 'EG',
    game: 'Senet', alias: 'An ancient Egyptian board game associated with movement, fate and the afterlife.',
    description: 'Senet is an ancient Egyptian board game played on a grid of thirty squares, with pieces moved according to throw sticks or casting lots.',
    preview: 'assets/vn-preview.png', title: 'Senet Board', type: 'Ancient board game', markerColor: '#a8652d', labelX: '24px', labelY: '-22px',
    steps: ['Set pieces on the thirty-square board.', 'Cast sticks or lots to determine movement.', 'Race pieces through the board while navigating special squares.']
  },
  newZealand: {
    number: '034 / 034', country: 'New Zealand', seal: 'NZ', stamp: 'NZ',
    game: 'Mū Tōrere', alias: 'A traditional Māori strategy game played on an eight-pointed board.',
    description: 'Traditional Māori strategy game played on an eight-pointed board where players attempt to block their opponent.',
    preview: 'assets/jp-card.png', title: 'Mū Tōrere Board', type: 'Strategy board game', markerColor: '#5d77aa', labelX: '-110px',
    steps: ['Place pieces around the eight-pointed board.', 'Move into legal connected points.', 'Win by blocking the opponent from moving.']
  }
};

Object.assign(countries, atlasEntries);
Object.keys(countries).forEach((key, index, keys) => {
  countries[key].number = `${String(index + 1).padStart(3, '0')} / ${String(keys.length).padStart(3, '0')}`;
});

/* =========================================================
   FULL JOURNEY DATA — welcome / name / intro / lore
   ========================================================= */
const journey = {
  mongolia: {
    country: 'Mongolia', code: 'MN', game: 'Shagai',
    welcomeIntro: 'Shagai are the anklebones of sheep, used for centuries across the Mongolian steppe for games, fortune-telling and teaching children to count and observe.',
    prompt: 'Before you begin, discover how your name appears in Mongolian.',
    illustration: '✦',
    nameHeading: 'How does your name look in Mongolian?',
    scriptLabel: 'Mongolian Cyrillic (stylised transliteration)',
    transliterate: latinToMongolianCyrillic,
    introSummary: 'Four anklebones, four possible landings. Learn what each position means before your first throw.',
    positions: [
      { icon: '𝍫', name: 'Horse', meaning: 'Considered a fortunate, forward-moving position — associated with speed and opportunity.' },
      { icon: '𝍪', name: 'Camel', meaning: 'A steady, enduring position — associated with resilience over a long journey.' },
      { icon: '𝍩', name: 'Sheep', meaning: 'The most common landing — associated with gentleness and the everyday.' },
      { icon: '𝍨', name: 'Goat', meaning: 'Considered the least favourable of the four — associated with caution.' }
    ],
    metaCards: [
      { icon: '◈', title: 'Equipment', text: 'Four dried sheep anklebones (shagai), sometimes painted or dyed.' },
      { icon: '◈', title: 'How to play', text: 'Cast all four bones onto a flat surface and read the combination of positions.' },
      { icon: '◈', title: 'Cultural meaning', text: 'Used in games, teaching and divination across Mongolian herding communities. [Illustrative — verify with cultural sources.]' }
    ],
    fact: 'Shagai (anklebones) have been used across the Mongolian steppe for centuries in games, divination and teaching children to count. [Placeholder — verify specifics with cultural sources.]',
    takeaway: 'A short reflection: across cultures, simple objects — bones, seeds, shells — became tools for chance, memory and connection.',
    hasFullGame: true
  },
  vietnam: {
    country: 'Vietnam', code: 'VN', game: 'Ô Ăn Quan',
    welcomeIntro: 'Ô Ăn Quan is a counting and capturing game played on a simple earthen or paper board, passed between generations of Vietnamese children.',
    prompt: 'Before you begin, discover how your name appears in Vietnamese.',
    illustration: '越',
    nameHeading: 'How does your name look in Vietnamese?',
    scriptLabel: 'Vietnamese diacritics (decorative, not an authentic equivalent)',
    transliterate: decorateVietnamese,
    introSummary: 'A board of small fields, a handful of seeds, and careful counting — this exhibit is still being prepared.',
    positions: [],
    metaCards: [
      { icon: '◈', title: 'Equipment', text: 'A board of ten small fields and two larger “quan” fields, with stones or seeds.' },
      { icon: '◈', title: 'How to play', text: 'Sow seeds field by field, capturing where a field is left with exactly two.' },
      { icon: '◈', title: 'Cultural meaning', text: 'A game of patience and mental arithmetic played across generations in Vietnam.' }
    ],
    fact: 'Ô Ăn Quan has long been played by children across Vietnam using stones, seeds or tamarind pips. [Placeholder — verify specifics with cultural sources.]',
    takeaway: 'This full playable exhibit is still being prepared — thank you for visiting the archive entry.',
    hasFullGame: false
  },
  japan: {
    country: 'Japan', code: 'JP', game: 'Kemari',
    welcomeIntro: 'Kemari is a cooperative, ceremonial ball game associated with Japan’s imperial court, where grace mattered more than winning.',
    prompt: 'Before you begin, discover how your name appears in Japanese.',
    illustration: '日',
    nameHeading: 'How does your name look in Japanese?',
    scriptLabel: 'Katakana (approximate phonetic rendering)',
    transliterate: romajiToKatakana,
    introSummary: 'A quiet, ceremonial ball game kept aloft by cooperation — this exhibit is still being prepared.',
    positions: [],
    metaCards: [
      { icon: '◈', title: 'Equipment', text: 'A deerskin ball (mari) and a marked circle of participants.' },
      { icon: '◈', title: 'How to play', text: 'Players keep the ball airborne together using controlled kicks, without competing.' },
      { icon: '◈', title: 'Cultural meaning', text: 'Historically associated with Japan’s Heian-era imperial court and courtly refinement.' }
    ],
    fact: 'Kemari is documented as a courtly pastime in Japan for over a thousand years. [Placeholder — verify specifics with cultural sources.]',
    takeaway: 'This full playable exhibit is still being prepared — thank you for visiting the archive entry.',
    hasFullGame: false
  },
  ghana: {
    country: 'Ghana', code: 'GH', game: 'Oware',
    welcomeIntro: 'Oware is a sowing and capturing game from the mancala family, played socially across West Africa for generations.',
    prompt: 'Before you begin, discover a stylised rendering of your name.',
    illustration: '✦',
    nameHeading: 'A stylised rendering of your name',
    scriptLabel: 'Illustrative phonetic rendering (not a formal transliteration)',
    transliterate: phoneticRespell,
    introSummary: 'Seeds, pits, and careful sowing — this exhibit is still being prepared.',
    positions: [],
    metaCards: [
      { icon: '◈', title: 'Equipment', text: 'A wooden board of twelve pits, plus stores, and 48 seeds or small stones.' },
      { icon: '◈', title: 'How to play', text: 'Sow seeds counter-clockwise from a chosen pit, capturing under set conditions.' },
      { icon: '◈', title: 'Cultural meaning', text: 'Played socially and taught directly across generations throughout West Africa.' }
    ],
    fact: 'Oware belongs to the wider mancala family of games found across Africa and parts of Asia. [Placeholder — verify specifics with cultural sources.]',
    takeaway: 'This full playable exhibit is still being prepared — thank you for visiting the archive entry.',
    hasFullGame: false
  }
};

Object.entries(atlasEntries).forEach(([key, c]) => {
  journey[key] = {
    country: c.country,
    code: c.stamp,
    game: c.game,
    welcomeIntro: c.description,
    prompt: `Before you begin, add your name to the ${c.country} archive passport.`,
    illustration: c.seal,
    nameHeading: `A visitor passport for ${c.country}`,
    scriptLabel: 'Visitor name rendering (prototype)',
    transliterate: phoneticRespell,
    introSummary: c.alias,
    positions: [],
    metaCards: [
      { icon: '◈', title: 'Equipment', text: c.title },
      { icon: '◈', title: 'How to play', text: c.steps.join(' ') },
      { icon: '◈', title: 'Cultural meaning', text: `${c.game} is represented here as part of ${c.country}'s living play traditions.` }
    ],
    fact: `${c.description} [Prototype archive entry — verify details with cultural sources before publication.]`,
    takeaway: `You explored ${c.game} from ${c.country}. This archive entry can later be expanded into a playable mini-game.`,
    hasFullGame: false
  };
});

/* =========================================================
   Stylised name transliteration helpers (illustrative only)
   ========================================================= */
function latinToMongolianCyrillic(name) {
  const map = { a:'а',b:'б',c:'к',d:'д',e:'э',f:'ф',g:'г',h:'х',i:'и',j:'ж',k:'к',l:'л',m:'м',n:'н',o:'о',p:'п',q:'к',r:'р',s:'с',t:'т',u:'у',v:'в',w:'в',x:'кс',y:'й',z:'з' };
  return name.split('').map(ch => {
    const lower = ch.toLowerCase();
    if (!/[a-z]/.test(lower)) return ch;
    const mapped = map[lower] || lower;
    return ch === lower ? mapped : mapped.charAt(0).toUpperCase() + mapped.slice(1);
  }).join('');
}

function romajiToKatakana(name) {
  const digraphs = { th:'ス', sh:'シ', ch:'チ', ph:'フ', ck:'ク' };
  const vowels = { a:'ア', e:'エ', i:'イ', o:'オ', u:'ウ' };
  const consonants = { b:'バ',c:'カ',d:'ダ',f:'ファ',g:'ガ',h:'ハ',j:'ジャ',k:'カ',l:'ラ',m:'マ',n:'ン',p:'パ',q:'ク',r:'ラ',s:'サ',t:'タ',v:'ヴァ',w:'ワ',x:'クス',y:'ヤ',z:'ザ' };
  let out = '';
  const s = name.toLowerCase().replace(/[^a-z]/g, '');
  for (let i = 0; i < s.length; i++) {
    const two = s.slice(i, i + 2);
    if (digraphs[two]) { out += digraphs[two]; i++; continue; }
    const ch = s[i];
    if (vowels[ch]) { out += vowels[ch]; continue; }
    out += consonants[ch] || '';
  }
  return out || 'ー';
}

function decorateVietnamese(name) {
  const marks = ['', '̀', '́', '̉', '̃', '̣'];
  return name.split('').map((ch, i) => /[a-zA-Z]/.test(ch) && /[aeiouAEIOU]/.test(ch) ? ch + marks[i % marks.length] : ch).join('');
}

function phoneticRespell(name) {
  const map = { c:'k', qu:'kw', x:'z', th:'t', ph:'f' };
  let s = name.toLowerCase();
  Object.entries(map).forEach(([k, v]) => { s = s.split(k).join(v); });
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/* =========================================================
   SCREEN ROUTER
   ========================================================= */
let activeScreen = 'home';
let selectedCountry = 'mongolia';
let selectedMode = 'solo';
const completedCountries = new Set();
const screenNavGroup = {
  intro: null,
  home: 'home',
  worldmap: 'worldmap',
  welcome: 'cultures',
  name: 'cultures',
  gameintro: 'games',
  game: 'games',
  complete: null
};

function showScreen(name, opts = {}) {
  activeScreen = name;
  document.body.classList.toggle('intro-active', name === 'intro');
  if (name === 'intro') {
    const panel = q('#leaderboardPanel');
    if (panel) panel.hidden = true;
    runIntroStats();
  }
  const shell = q('.app-shell');
  if (!opts.instant && shell) {
    shell.classList.remove('route-changing');
    void shell.offsetWidth;
    shell.classList.add('route-changing');
    window.setTimeout(() => shell.classList.remove('route-changing'), 650);
  }
  qa('.screen').forEach(s => s.classList.toggle('active', s.dataset.screen === name));
  if (name === 'worldmap') {
    requestAnimationFrame(() => {
      initLeafletMap();
      if (leafletMap) {
        leafletMap.invalidateSize();
        if (!previewCountry) leafletMap.setView(mapCenter, 2);
      }
    });
  } else {
    closeAtlasPreview();
  }
  const activeNav = screenNavGroup[name] || name;
  qa('.nav-item').forEach(el => {
    const key = el.dataset.nav || el.dataset.scroll;
    el.classList.toggle('active', Boolean(activeNav) && key === activeNav);
  });
  window.scrollTo({ top: 0, behavior: opts.instant ? 'auto' : 'smooth' });
}

function updateCompletionMarkers() {
  qa('[data-country]').forEach(el => {
    const isComplete = completedCountries.has(el.dataset.country);
    el.classList.toggle('completed', isComplete);
    if (el.classList.contains('map-pin')) {
      const country = countries[el.dataset.country];
      const status = isComplete ? 'completed' : 'not completed';
      el.setAttribute('aria-label', `${country.country}, ${country.game}, ${status}. Explore`);
    }
  });

  const status = q('#atlasStatus');
  if (status) {
    status.textContent = completedCountries.size
      ? `Passport stamped: ${[...completedCountries].map(key => countries[key].country).join(', ')}`
      : 'No passport stamps recorded yet.';
  }
  refreshLeafletMarkers();
}

/* =========================================================
   INTRO — pre-home game entry
   ========================================================= */
const introTranslations = {
  en: {
    title: 'Culture Game',
    navHow: 'How it works',
    navModes: 'Modes',
    navLeaderboard: 'Leaderboard',
    languageLabel: 'Language',
    welcome: 'Welcome, cultural traveller · Personal best —',
    copy: 'Enter a living archive of traditional play, explore cultures through games, and collect passport stamps as you learn.',
    plays: 'Plays',
    duels: 'Duels',
    worldRecord: 'World record',
    solo: 'Solo',
    soloSmall: 'Begin the archive journey',
    duel: 'Duel',
    duelSmall: 'Prototype challenge mode',
    viewLeaderboard: 'View Leaderboard',
    howOneTitle: 'Select a culture',
    howOneText: 'Use the atlas to choose a marked country.',
    howTwoTitle: 'Learn the tradition',
    howTwoText: 'Read the archive entry and receive a passport card.',
    howThreeTitle: 'Play the game',
    howThreeText: 'Try the Shagai showcase and collect a stamp.',
    boardTitle: 'Global archive ranking',
    closeLeaderboard: 'Close leaderboard',
    chooseLanguage: 'Choose language'
  },
  ja: {
    title: 'カルチャーゲーム',
    navHow: '遊び方',
    navModes: 'モード',
    navLeaderboard: 'ランキング',
    languageLabel: '言語',
    welcome: 'ようこそ、文化の旅人 · 自己ベスト —',
    copy: '伝統的な遊びの生きたアーカイブに入り、ゲームを通して文化を探索し、学びながらパスポートスタンプを集めましょう。',
    plays: 'プレイ数',
    duels: '対戦数',
    worldRecord: '世界記録',
    solo: 'ソロ',
    soloSmall: 'アーカイブの旅を始める',
    duel: 'デュエル',
    duelSmall: 'プロトタイプ対戦モード',
    viewLeaderboard: 'ランキングを見る',
    howOneTitle: '文化を選ぶ',
    howOneText: 'アトラスで印のある国を選びます。',
    howTwoTitle: '伝統を学ぶ',
    howTwoText: 'アーカイブ記事を読み、パスポートカードを受け取ります。',
    howThreeTitle: 'ゲームを遊ぶ',
    howThreeText: 'シャガイ展示を体験し、スタンプを集めます。',
    boardTitle: 'グローバルアーカイブランキング',
    closeLeaderboard: 'ランキングを閉じる',
    chooseLanguage: '言語を選択'
  },
  vi: {
    title: 'Trò Chơi Văn Hóa',
    navHow: 'Cách chơi',
    navModes: 'Chế độ',
    navLeaderboard: 'Bảng xếp hạng',
    languageLabel: 'Ngôn ngữ',
    welcome: 'Chào mừng nhà du hành văn hóa · Thành tích tốt nhất —',
    copy: 'Bước vào kho lưu trữ sống của trò chơi truyền thống, khám phá văn hóa qua trò chơi và sưu tầm dấu hộ chiếu khi học.',
    plays: 'Lượt chơi',
    duels: 'Đấu tay đôi',
    worldRecord: 'Kỷ lục thế giới',
    solo: 'Chơi đơn',
    soloSmall: 'Bắt đầu hành trình lưu trữ',
    duel: 'Đấu',
    duelSmall: 'Chế độ thử thách mẫu',
    viewLeaderboard: 'Xem bảng xếp hạng',
    howOneTitle: 'Chọn một nền văn hóa',
    howOneText: 'Dùng bản đồ để chọn quốc gia được đánh dấu.',
    howTwoTitle: 'Tìm hiểu truyền thống',
    howTwoText: 'Đọc mục lưu trữ và nhận thẻ hộ chiếu.',
    howThreeTitle: 'Chơi trò chơi',
    howThreeText: 'Thử phần trưng bày Shagai và nhận dấu.',
    boardTitle: 'Xếp hạng lưu trữ toàn cầu',
    closeLeaderboard: 'Đóng bảng xếp hạng',
    chooseLanguage: 'Chọn ngôn ngữ'
  },
  zh: {
    title: '文化游戏',
    navHow: '玩法介绍',
    navModes: '模式',
    navLeaderboard: '排行榜',
    languageLabel: '语言',
    welcome: '欢迎回来，文化旅人 · 个人最佳 —',
    copy: '进入传统游戏的活态档案，通过游戏探索文化，并在学习中收集护照印章。',
    plays: '游玩次数',
    duels: '对战次数',
    worldRecord: '世界纪录',
    solo: '单人',
    soloSmall: '开始档案旅程',
    duel: '对战',
    duelSmall: '原型挑战模式',
    viewLeaderboard: '查看排行榜',
    howOneTitle: '选择文化',
    howOneText: '使用地图选择已标记的国家。',
    howTwoTitle: '了解传统',
    howTwoText: '阅读档案条目并领取护照卡。',
    howThreeTitle: '体验游戏',
    howThreeText: '尝试沙嘎展示并收集印章。',
    boardTitle: '全球档案排名',
    closeLeaderboard: '关闭排行榜',
    chooseLanguage: '选择语言'
  },
  ko: {
    title: '문화 게임',
    navHow: '이용 방법',
    navModes: '모드',
    navLeaderboard: '리더보드',
    languageLabel: '언어',
    welcome: '문화 여행자님, 환영합니다 · 개인 최고 기록 —',
    copy: '전통 놀이의 살아 있는 아카이브에 들어가 게임을 통해 문화를 탐험하고, 배워 가며 여권 스탬프를 모아 보세요.',
    plays: '플레이',
    duels: '대결',
    worldRecord: '세계 기록',
    solo: '솔로',
    soloSmall: '아카이브 여정 시작',
    duel: '듀얼',
    duelSmall: '프로토타입 도전 모드',
    viewLeaderboard: '리더보드 보기',
    howOneTitle: '문화 선택',
    howOneText: '지도에서 표시된 국가를 선택하세요.',
    howTwoTitle: '전통 배우기',
    howTwoText: '아카이브 항목을 읽고 여권 카드를 받으세요.',
    howThreeTitle: '게임 플레이',
    howThreeText: '샤가이 전시를 체험하고 스탬프를 모으세요.',
    boardTitle: '글로벌 아카이브 순위',
    closeLeaderboard: '리더보드 닫기',
    chooseLanguage: '언어 선택'
  }
};

function applyIntroLanguage(lang) {
  const dictionary = introTranslations[lang] || introTranslations.en;
  qa('[data-i18n]').forEach(el => {
    const value = dictionary[el.dataset.i18n];
    if (value) el.textContent = value;
  });
  q('#leaderboardCloseBtn')?.setAttribute('aria-label', dictionary.closeLeaderboard);
  q('#introLanguageSelect')?.setAttribute('aria-label', dictionary.chooseLanguage);
  document.documentElement.lang = lang;
}

function animateIntroCount(el, end, duration = 900) {
  if (!el) return;
  const start = Math.max(0, Math.floor(end * .86));
  const startTime = performance.now();

  function tick(now) {
    const t = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - t, 3);
    const value = Math.round(start + (end - start) * eased);
    el.textContent = value.toLocaleString();
    if (t < 1) requestAnimationFrame(tick);
  }

  requestAnimationFrame(tick);
}

function runIntroStats() {
  animateIntroCount(q('#introPlays'), 18290693, 1100);
  animateIntroCount(q('#introDuels'), 534844, 1000);
  animateIntroCount(q('#introRecord'), 899, 850);
}

function enterFromIntro(mode) {
  selectedMode = mode;
  const status = q('#atlasStatus');
  if (status && !completedCountries.size) {
    status.textContent = mode === 'duel'
      ? 'Duel mode selected: choose a culture to begin the challenge.'
      : 'Solo mode selected: explore the archive at your own pace.';
  }
  showScreen(mode === 'duel' ? 'worldmap' : 'home');
}

q('#soloStartBtn')?.addEventListener('click', () => enterFromIntro('solo'));
q('#duelStartBtn')?.addEventListener('click', () => enterFromIntro('duel'));
q('#introLanguageSelect')?.addEventListener('change', e => applyIntroLanguage(e.target.value));
q('#leaderboardBtn')?.addEventListener('click', () => {
  q('#leaderboardPanel').hidden = false;
});
q('#leaderboardCloseBtn')?.addEventListener('click', () => {
  q('#leaderboardPanel').hidden = true;
});
qa('[data-intro-jump]').forEach(btn => btn.addEventListener('click', () => {
  const target = q(`#${btn.dataset.introJump === 'leaderboard' ? 'leaderboardPanel' : btn.dataset.introJump}`);
  if (btn.dataset.introJump === 'leaderboard') {
    q('#leaderboardPanel').hidden = false;
    return;
  }
  target?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}));

qa('[data-nav]').forEach(el => el.addEventListener('click', e => {
  e.preventDefault();
  showScreen(el.dataset.nav);
}));

q('#mapPreviewBtn').addEventListener('click', () => showScreen('worldmap'));

qa('[data-scroll]').forEach(btn => btn.addEventListener('click', () => {
  showScreen('home', { instant: true });
  requestAnimationFrame(() => {
    const target = document.getElementById(btn.dataset.scroll);
    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
}));

/* =========================================================
   HOME — exhibit panel + about dialog
   ========================================================= */
function selectHomeCountry(key) {
  const c = countries[key];
  if (!c) return;
  selectedCountry = key;
  q('#entryNumber').textContent = c.number;
  q('#countryName').textContent = c.country;
  q('#flagSeal').textContent = c.seal;
  q('#catalogueStamp').textContent = c.stamp;
  q('#gameName').textContent = c.game;
  q('#gameAlias').textContent = c.alias;
  q('#description').textContent = c.description;
  q('#previewImage').src = c.preview;
  q('#previewImage').alt = `Preview of ${c.game}`;
  q('#videoCaption').textContent = `Watch ${c.game} being played`;
  qa('[data-country]').forEach(el => el.classList.toggle('active', el.dataset.country === key));
  refreshLeafletMarkers();
  updateCompletionMarkers();
  homeStep = 0;
  renderHomeStep();

  const exhibit = q('.exhibit');
  exhibit.animate([
    { opacity: .72, transform: 'translateY(6px)' },
    { opacity: 1, transform: 'translateY(0)' }
  ], { duration: 260, easing: 'ease-out' });
}

let homeStep = 0;
function renderHomeStep() {
  const c = countries[selectedCountry];
  q('#stepCount').textContent = `Step ${homeStep + 1} / 3`;
  q('#stepText').textContent = c.steps[homeStep];
  q('#stepFocus').style.left = `${homeStep * 33.333}%`;
}

qa('.game-card[data-country]').forEach(el => el.addEventListener('click', () => selectHomeCountry(el.dataset.country)));
q('#nextStep').addEventListener('click', () => { homeStep = (homeStep + 1) % 3; renderHomeStep(); });
q('#prevStep').addEventListener('click', () => { homeStep = (homeStep + 2) % 3; renderHomeStep(); });

q('#videoPreview').addEventListener('click', () => {
  const cap = q('#videoCaption');
  const play = q('.play-button');
  const el = q('#videoPreview');
  if (!el.classList.contains('playing')) {
    el.classList.add('playing');
    play.textContent = 'Ⅱ';
    cap.textContent = 'Demo video placeholder · replace with your MP4';
  } else {
    el.classList.remove('playing');
    play.textContent = '▶';
    cap.textContent = `Watch ${countries[selectedCountry].game} being played`;
  }
});

const aboutDialog = q('#aboutDialog');
q('#aboutBtn').addEventListener('click', () => aboutDialog.showModal());
qa('[data-close-dialog]').forEach(btn => btn.addEventListener('click', () => btn.closest('dialog').close()));
qa('dialog').forEach(d => d.addEventListener('click', e => {
  const r = d.getBoundingClientRect();
  if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) d.close();
}));

q('#exploreBtn').addEventListener('click', () => beginJourney(selectedCountry));

/* =========================================================
   WORLD MAP — Leaflet atlas + cinematic travel
   ========================================================= */
const worldmapStage = q('#worldmapStage');
const leafletMapEl = q('#leafletMap');
const atlasPreviewPanel = q('#atlasPreviewPanel');
let previewCountry = null;
let leafletMap = null;
const leafletMarkers = new Map();
const mapCenter = [25, 48];
const mapLocations = {
  mongolia: [46.8625, 103.8467],
  japan: [36.2048, 138.2529],
  vietnam: [14.0583, 108.2772],
  ghana: [7.9465, -1.0232],
  southKorea: [35.9078, 127.7669],
  china: [35.8617, 104.1954],
  india: [20.5937, 78.9629],
  thailand: [15.8700, 100.9925],
  philippines: [12.8797, 121.7740],
  indonesia: [-0.7893, 113.9213],
  malaysia: [4.2105, 101.9758],
  kazakhstan: [48.0196, 66.9237],
  turkiye: [38.9637, 35.2433],
  greece: [39.0742, 21.8243],
  portugal: [39.3999, -8.2245],
  italy: [41.8719, 12.5674],
  spain: [40.4637, -3.7492],
  unitedKingdom: [52.3555, -1.1743],
  ireland: [53.1424, -7.6921],
  netherlands: [52.1326, 5.2913],
  finland: [61.9241, 25.7482],
  sweden: [60.1282, 18.6435],
  switzerland: [46.8182, 8.2275],
  mexico: [23.6345, -102.5528],
  unitedStates: [37.0902, -95.7129],
  canada: [56.1304, -106.3468],
  brazil: [-14.2350, -51.9253],
  argentina: [-38.4161, -63.6167],
  chile: [-35.6751, -71.5430],
  peru: [-9.1900, -75.0152],
  southAfrica: [-30.5595, 22.9375],
  kenya: [-0.0236, 37.9062],
  egypt: [26.8206, 30.8025],
  newZealand: [-40.9006, 174.8860]
};
const hiddenMapCountries = new Set([
  'thailand',
  'philippines',
  'indonesia',
  'malaysia',
  'kyrgyzstan',
  'greece',
  'spain',
  'ireland',
  'netherlands',
  'switzerland'
]);
const continentWashes = [
  { name: 'North America', color: '#557346', coords: [[72, -168], [70, -55], [46, -52], [18, -86], [12, -112], [33, -137], [55, -168]] },
  { name: 'South America', color: '#587f46', coords: [[13, -82], [9, -48], [-54, -57], [-55, -76], [-22, -82]] },
  { name: 'Europe', color: '#b87a38', coords: [[72, -12], [66, 42], [43, 46], [35, 20], [36, -10]] },
  { name: 'Africa', color: '#a0772f', coords: [[35, -18], [33, 52], [-35, 49], [-36, 16], [-20, -17]] },
  { name: 'Asia', color: '#9a5738', coords: [[75, 38], [68, 165], [7, 153], [-9, 100], [18, 58], [48, 44]] },
  { name: 'Oceania', color: '#5a6f9f', coords: [[-7, 111], [-8, 179], [-48, 178], [-47, 113]] }
];
const continentLabels = [
  { name: 'North America', coords: [47, -103] },
  { name: 'South America', coords: [-24, -61] },
  { name: 'Europe', coords: [55, 18] },
  { name: 'Africa', coords: [5, 21] },
  { name: 'Asia', coords: [48, 93] },
  { name: 'Oceania', coords: [-25, 139] }
];

function markerTooltip(key) {
  const c = countries[key];
  return `
    <span class="leaflet-tip-card">
      <b>${c.country}</b>
      <em>${c.game} · ${c.type}</em>
      <i class="pin-thumb">${c.seal}</i>
      <strong class="pin-action">Explore</strong>
    </span>
  `;
}

function createArchiveIcon(key) {
  const c = countries[key];
  const markerColor = c.markerColor || '#c59952';
  const labelX = c.labelX || '27px';
  const labelY = c.labelY || '-6px';
  return L.divIcon({
    className: 'map-pin leaflet-country-marker',
    html: `<span class="map-pin-content" style="--marker-color:${markerColor};--label-x:${labelX};--label-y:${labelY}"><span class="map-pin-dot"></span><span class="map-pin-label">${c.country}</span></span>`,
    iconSize: [18, 18],
    iconAnchor: [7, 14]
  });
}

function refreshLeafletMarkers() {
  leafletMarkers.forEach((marker, key) => {
    const el = marker.getElement();
    if (!el) return;
    const isComplete = completedCountries.has(key);
    const isActive = selectedCountry === key;
    const c = countries[key];
    el.dataset.country = key;
    el.classList.toggle('completed', isComplete);
    el.classList.toggle('active', isActive);
    el.classList.toggle('previewing', previewCountry === key);
    el.setAttribute('aria-label', `${c.country}, ${c.game}, ${isComplete ? 'completed' : 'not completed'}. Explore`);
  });
}

function closeAtlasPreview(resetMap = false) {
  if (atlasPreviewPanel) atlasPreviewPanel.hidden = true;
  previewCountry = null;
  if (worldmapStage) worldmapStage.classList.remove('preview-open');
  refreshLeafletMarkers();
  if (resetMap && leafletMap) leafletMap.flyTo(mapCenter, 2, { animate: true, duration: .45 });
}

function fillAtlasPreview(key) {
  const c = countries[key];
  if (!c) return;
  q('#atlasPreviewNumber').textContent = c.number;
  q('#atlasPreviewSeal').textContent = c.stamp;
  q('#atlasPreviewCountry').textContent = c.country;
  q('#atlasPreviewGame').textContent = c.game;
  q('#atlasPreviewDescription').textContent = c.description;
  q('#atlasPreviewObject').textContent = c.title;
  q('#atlasPreviewType').textContent = c.type;
}

function openAtlasPreview(key) {
  if (!journey[key]) return;
  initLeafletMap();
  previewCountry = key;
  selectedCountry = key;
  fillAtlasPreview(key);
  if (atlasPreviewPanel) atlasPreviewPanel.hidden = false;
  if (worldmapStage) worldmapStage.classList.add('preview-open');
  refreshLeafletMarkers();

  const status = q('#atlasStatus');
  if (status) status.textContent = `${countries[key].country} selected: read the introduction, join the game, or expand the full entry.`;
  if (leafletMap && mapLocations[key]) {
    leafletMap.flyTo(mapLocations[key], 5, { animate: true, duration: .75 });
  }
}

function initLeafletMap() {
  if (!leafletMapEl || leafletMap || !window.L) return;

  leafletMap = L.map(leafletMapEl, {
    attributionControl: true,
    maxBounds: [[-72, -190], [84, 190]],
    maxBoundsViscosity: .35,
    minZoom: 2,
    maxZoom: 6,
    scrollWheelZoom: false,
    worldCopyJump: true,
    zoomControl: true
  }).setView(mapCenter, 2);

  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 6,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(leafletMap);

  leafletMap.createPane('continentWashPane');
  leafletMap.getPane('continentWashPane').style.zIndex = 230;
  leafletMap.getPane('continentWashPane').style.pointerEvents = 'none';
  leafletMap.createPane('continentLabelPane');
  leafletMap.getPane('continentLabelPane').style.zIndex = 430;
  leafletMap.getPane('continentLabelPane').style.pointerEvents = 'none';

  continentWashes.forEach(({ color, coords }) => {
    L.polygon(coords, {
      pane: 'continentWashPane',
      interactive: false,
      stroke: false,
      fillColor: color,
      fillOpacity: .24,
      className: 'continent-wash'
    }).addTo(leafletMap);
  });

  continentLabels.forEach(({ name, coords }) => {
    L.marker(coords, {
      pane: 'continentLabelPane',
      interactive: false,
      icon: L.divIcon({
        className: 'continent-label-marker',
        html: `<span>${name}</span>`,
        iconSize: [190, 34],
        iconAnchor: [95, 17]
      })
    }).addTo(leafletMap);
  });

  Object.entries(mapLocations).filter(([key]) => !hiddenMapCountries.has(key)).forEach(([key, coords]) => {
    const marker = L.marker(coords, {
      icon: createArchiveIcon(key),
      keyboard: true,
      title: `${countries[key].country} · ${countries[key].game}`
    }).addTo(leafletMap);
    marker.bindTooltip(markerTooltip(key), {
      className: 'leaflet-archive-tip',
      direction: 'top',
      offset: [0, -18],
      opacity: 1
    });
    marker.on('mouseover', () => selectHomeCountry(key));
    marker.on('click', () => openAtlasPreview(key));
    leafletMarkers.set(key, marker);
  });

  refreshLeafletMarkers();
}

q('#atlasPreviewClose')?.addEventListener('click', () => closeAtlasPreview(true));
q('#atlasPreviewJoin')?.addEventListener('click', () => beginJourney(previewCountry || selectedCountry));

/* =========================================================
   JOURNEY — welcome, name, intro, game, completion
   ========================================================= */
function beginJourney(key) {
  if (!journey[key]) return;
  selectedCountry = key;
  const j = journey[key];

  q('#welcomeEyebrow').textContent = 'CULTURAL INTRODUCTION';
  q('#welcomeTitle').textContent = `Welcome to ${j.country}`;
  q('#welcomeGame').textContent = j.game;
  q('#welcomeIntro').textContent = j.welcomeIntro;
  q('#welcomePrompt').textContent = j.prompt;
  q('#welcomeIllustration').textContent = j.illustration;

  showScreen('welcome', { instant: true });
}

q('#welcomeContinue').addEventListener('click', () => {
  const j = journey[selectedCountry];
  q('#nameHeading').textContent = j.nameHeading;
  q('#nameInput').value = '';
  q('#passportCard').hidden = true;
  q('#nameForm').hidden = false;
  q('#passportCountryCode').textContent = j.code;
  q('#passportCountry').textContent = j.country;
  q('#passportScriptLabel').textContent = j.scriptLabel;
  q('#passportSealCode').textContent = j.code;
  showScreen('name', { instant: true });
});

q('#nameForm').addEventListener('submit', e => {
  e.preventDefault();
  const name = q('#nameInput').value.trim();
  if (!name) return;
  const j = journey[selectedCountry];
  const transformed = j.transliterate(name);

  q('#passportLede').textContent = `Your name in ${j.country === 'Mongolia' ? 'Mongolian' : j.country === 'Japan' ? 'Japanese' : j.country === 'Vietnam' ? 'Vietnamese' : j.country}'s style looks like:`;
  q('#passportScript').textContent = transformed;
  q('#passportName').textContent = name;
  q('#passportCard').hidden = false;
  q('#nameForm').hidden = true;
});

function showJourneyIntro(key = selectedCountry) {
  if (!journey[key]) return;
  selectedCountry = key;
  closeAtlasPreview();
  const j = journey[key];
  q('#introEyebrow').textContent = `${j.country} · ${j.game}`;
  q('#introTitle').textContent = j.game;
  q('#introSummary').textContent = j.introSummary;

  const cardsEl = q('#introCards');
  cardsEl.innerHTML = '';
  if (j.positions.length) {
    j.positions.forEach(p => {
      cardsEl.insertAdjacentHTML('beforeend', `
        <div class="intro-card">
          <div class="intro-icon">${p.icon}</div>
          <b>${p.name}</b>
          <p>${p.meaning}</p>
        </div>`);
    });
  }

  const metaEl = q('#introMetaCards');
  metaEl.innerHTML = '';
  j.metaCards.forEach(m => {
    metaEl.insertAdjacentHTML('beforeend', `
      <div class="intro-card">
        <div class="intro-icon">${m.icon}</div>
        <b>${m.title}</b>
        <p>${m.text}</p>
      </div>`);
  });

  q('#enterGameBtn').querySelector('span').textContent = j.hasFullGame ? 'Enter the Exhibit' : 'View Archive Entry';

  showScreen('gameintro', { instant: true });
}

q('#beginGameBtn').addEventListener('click', () => showJourneyIntro(selectedCountry));

q('#enterGameBtn').addEventListener('click', () => {
  const j = journey[selectedCountry];
  if (j.hasFullGame) {
    setupGameScreen();
    showScreen('game', { instant: true });
  } else {
    finishJourney();
  }
});

/* =========================================================
   MAIN GAME — Shagai (Mongolia)
   ========================================================= */
const positionNames = ['Horse', 'Camel', 'Sheep', 'Goat'];

function setupGameScreen() {
  q('#gameEyebrow').textContent = `${journey[selectedCountry].country} · ${journey[selectedCountry].game}`;
  resetTray();
  q('#loreResult').textContent = '— · — · — · —';
  q('#loreFortune').textContent = 'Awaiting your throw';
  q('#loreExplanation').textContent = 'Throw the Shagai to see a traditional-style interpretation of your result. Interpretations shown here are illustrative and simplified for this prototype — verify with cultural sources before treating them as authoritative.';
  q('#throwBtn').disabled = false;
  q('#finishGameBtn').disabled = true;
  q('#arenaHint').textContent = 'Click to cast all four anklebones onto the felt.';
}

function resetTray() {
  qa('.shagai-piece').forEach(p => {
    p.classList.remove('throwing', 'settled');
    p.style.animation = 'none';
    p.querySelectorAll('.piece-label').forEach(el => el.remove());
    void p.offsetWidth;
    p.style.animation = '';
  });
}

q('#throwBtn').addEventListener('click', () => {
  const btn = q('#throwBtn');
  btn.disabled = true;
  q('#arenaHint').textContent = 'The bones are tumbling…';
  resetTray();

  const results = [];
  const pieces = qa('.shagai-piece');
  pieces.forEach((piece) => {
    const result = positionNames[Math.floor(Math.random() * 4)];
    results.push(result);

    const tx1 = (Math.random() * 160 - 80).toFixed(0) + 'px';
    const ty1 = (Math.random() * 120 - 60).toFixed(0) + 'px';
    const tr1 = (Math.random() * 480 - 240).toFixed(0) + 'deg';
    const tx2 = (Math.random() * 100 - 50).toFixed(0) + 'px';
    const ty2 = (Math.random() * 80 - 40).toFixed(0) + 'px';
    const tr2 = (Math.random() * 300 - 150).toFixed(0) + 'deg';
    const txf = (Math.random() * 80 - 40).toFixed(0) + 'px';
    const tyf = (Math.random() * 60 - 30).toFixed(0) + 'px';
    const trf = (Math.random() * 60 - 30).toFixed(0) + 'deg';

    piece.style.setProperty('--tx1', tx1);
    piece.style.setProperty('--ty1', ty1);
    piece.style.setProperty('--tr1', tr1);
    piece.style.setProperty('--tx2', tx2);
    piece.style.setProperty('--ty2', ty2);
    piece.style.setProperty('--tr2', tr2);
    piece.style.setProperty('--txf', txf);
    piece.style.setProperty('--tyf', tyf);
    piece.style.setProperty('--trf', trf);
    piece.classList.add('throwing');
  });

  setTimeout(() => {
    pieces.forEach((piece, i) => {
      piece.classList.remove('throwing');
      piece.classList.add('settled');
      const label = document.createElement('span');
      label.className = 'piece-label';
      label.textContent = results[i];
      piece.appendChild(label);
      requestAnimationFrame(() => label.style.opacity = '1');
    });
    renderResult(results);
    btn.disabled = false;
    q('#arenaHint').textContent = 'Click to throw again, or record this reading.';
  }, 950);
});

function renderResult(results) {
  q('#loreResult').textContent = results.join(' · ');
  const unique = new Set(results).size;
  let fortune, explanation;
  if (unique === 4) {
    fortune = 'Bujiin Melkhii — a rare, fortunate throw';
    explanation = 'All four positions landing differently is traditionally seen as a rare and auspicious combination. [Illustrative simplification — verify with cultural sources.]';
  } else if (unique === 1) {
    fortune = 'A uniform throw';
    explanation = `All four bones landing as ${results[0]} is a striking, uncommon result. [Illustrative simplification — verify with cultural sources.]`;
  } else {
    fortune = 'A mixed reading';
    explanation = 'A blend of positions is the most common outcome, read alongside the game or fortune being played. [Illustrative simplification — verify with cultural sources.]';
  }
  q('#loreFortune').textContent = fortune;
  q('#loreExplanation').textContent = explanation;
  q('#finishGameBtn').disabled = false;
}

/* ---- museum-case 3D object viewer (drag / zoom / reset) ---- */
const bone3d = q('#bone3d');
let boneDragging = false, boneLastX = 0, boneLastY = 0, boneRX = -12, boneRY = 18, boneScale = 1;

function applyBoneTransform() {
  bone3d.style.transform = `scale(${boneScale}) perspective(700px) rotateX(${boneRX}deg) rotateY(${boneRY}deg)`;
}
applyBoneTransform();

bone3d.addEventListener('pointerdown', e => { boneDragging = true; boneLastX = e.clientX; boneLastY = e.clientY; bone3d.setPointerCapture(e.pointerId); bone3d.style.cursor = 'grabbing'; });
bone3d.addEventListener('pointermove', e => {
  if (!boneDragging) return;
  boneRY += (e.clientX - boneLastX) * .5;
  boneRX -= (e.clientY - boneLastY) * .4;
  boneLastX = e.clientX; boneLastY = e.clientY;
  applyBoneTransform();
});
bone3d.addEventListener('pointerup', () => { boneDragging = false; bone3d.style.cursor = 'grab'; });
bone3d.addEventListener('pointercancel', () => { boneDragging = false; bone3d.style.cursor = 'grab'; });

q('#caseZoomIn').addEventListener('click', () => { boneScale = Math.min(1.8, boneScale + .18); applyBoneTransform(); });
q('#caseZoomOut').addEventListener('click', () => { boneScale = Math.max(.5, boneScale - .18); applyBoneTransform(); });
q('#caseReset').addEventListener('click', () => { boneRX = -12; boneRY = 18; boneScale = 1; applyBoneTransform(); });

function idleBoneRotation() {
  if (!boneDragging && activeScreen === 'game') {
    boneRY += .12;
    applyBoneTransform();
  }
  requestAnimationFrame(idleBoneRotation);
}
requestAnimationFrame(idleBoneRotation);

/* =========================================================
   FINISH / COMPLETION
   ========================================================= */
q('#finishGameBtn').addEventListener('click', finishJourney);

function finishJourney() {
  const j = journey[selectedCountry];
  completedCountries.add(selectedCountry);
  q('#completeTitle').textContent = `You have experienced ${j.game} — ${j.country}.`;
  q('#stampCode').textContent = j.code;
  q('#stampGame').textContent = j.game;
  q('#stampCountry').textContent = j.country;
  q('#stampDate').textContent = new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
  q('#completionTakeaway').textContent = j.takeaway;
  updateCompletionMarkers();
  showScreen('complete', { instant: true });
}

q('#exploreAnotherBtn').addEventListener('click', () => {
  updateCompletionMarkers();
  showScreen('worldmap');
});

/* =========================================================
   INIT
   ========================================================= */
applyIntroLanguage(q('#introLanguageSelect')?.value || 'en');
selectHomeCountry('vietnam');
updateCompletionMarkers();
showScreen('intro', { instant: true });
